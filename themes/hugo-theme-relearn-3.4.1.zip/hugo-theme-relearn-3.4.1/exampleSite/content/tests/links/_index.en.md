+++
description = "Some testing for different styles of links"
title = "Links"
+++

Some testing for different styles of links.

## Markdown

### Relative to page:

![Magic](images/magic.gif?classes=shadow)

### Relative to page up level:

![Magic](../images/images/magic.gif?classes=shadow)

### Static:

![Logo](/images/logo.svg?classes=shadow)
