+++
disableToc = true
title = "Crrredits"
+++
{{< piratify >}}