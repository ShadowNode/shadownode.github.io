+++
title = "Multilingual an' i18n"
weight = 30
+++
{{< piratify >}}