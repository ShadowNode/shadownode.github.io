+++
title = "Arrrchetypes"
weight = 10
+++
{{< piratify >}}