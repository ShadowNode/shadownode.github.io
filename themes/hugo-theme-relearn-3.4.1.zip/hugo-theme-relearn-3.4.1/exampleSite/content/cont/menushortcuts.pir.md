+++
title = "Menu extrrra shorrrtcuts"
weight = 25
+++
{{< piratify >}}