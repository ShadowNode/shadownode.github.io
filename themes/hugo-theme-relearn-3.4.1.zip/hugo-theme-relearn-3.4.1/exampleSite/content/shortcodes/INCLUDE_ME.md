You can add:

- multiple paragraphs
- bullet point lists
- _emphasized_, **bold** and even **_bold emphasized_** text
- [links](https://example.com)
- other shortcodes besides `include`
- etc.

```plaintext
...and even source code
```

> the possiblities are endless
