+++
description = "This is a demo child page"
tags = ["children", "non-hidden"]
title = "page 1-1-2"
+++

This is a plain demo child page.

## Subpages of this page

{{% children showhidden="true" %}}
