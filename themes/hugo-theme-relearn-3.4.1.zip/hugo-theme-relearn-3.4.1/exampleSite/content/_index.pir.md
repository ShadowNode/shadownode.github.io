+++
title = "Cap'n Hugo Relearrrn Theme"
+++
{{< piratify >}}