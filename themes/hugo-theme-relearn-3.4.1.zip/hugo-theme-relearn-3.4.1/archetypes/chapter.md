+++
chapter = true
pre = "<b>X. </b>"
title = "{{ replace .Name "-" " " | title }}"
weight = 5
+++

### Chapter X

# Some Chapter title

Lorem Ipsum.